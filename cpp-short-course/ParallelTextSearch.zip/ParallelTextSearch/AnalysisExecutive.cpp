///////////////////////////////////////////////////////////////////////////
// AnalysisExecutive - This package runs a Parallel Text Search Process  //
//                                                                       //
// Jim Fawcett, CSE775 - Distributed Objects, Spring 2016                //
///////////////////////////////////////////////////////////////////////////
/*
* This package sets up event handling and data flow in a processing 
* pipeline, using a ThreadPool and Task class to manage a lot of 
* concurrency in a relatively easy way.
*
* The solution uses packages:
* - AnalysisExecutive  - Root of the analysis packages with the project's
*                        entry point.
* - ParallelTextSearch - ParallelTextSearch, TextSearch, Display,
*                        and EventHandler classes
* - IFileMgr           - IFileMgr interface
* - FileMgr            - FileMgr, AnalFileEventHandler, AnalDirEventHandler,
*                        and AnalDoneEventHandler classes
* - Task               - Task class
* - ThreadPool         - ThreadPool class
* - Logger             - Logger and StaticLogger<size_t>
* - BlockingQueue      - BlockingQueue<T> used by the three previous packages
* - Utilities          - Converter<T> has toString and toValue methods,
*                        and several other helper classes
*/
#include "ParallelTextSearch.h"
#include "../Utilities/Utilities.h"
#include <string>
#include <vector>
#include <iostream>

using namespace Utilities;
using Utils = StringHelper;

class AnalysisExecutive
{
public:
  using Path = std::string;
  using Pattern = std::string;
  using Patterns = std::vector<Pattern>;

  bool parseCommandLine(int argc, char* argv[]);
  void doAnalysis();
private:
  Path path_;
  Patterns filePatterns_;
  Patterns textPatterns_;
};
//----< parse command line arguments >-------------------------------
/*
 * The command line format looks like this:
 *   /p .. /f *.h *.cpp /t thread sockets "static int"
 */
bool AnalysisExecutive::parseCommandLine(int argc, char* argv[])
{
  std::cout << "\n  commandline: ";
  for (int i = 1; i < argc; ++i)
    std::cout << argv[i] << " ";

  if (argc < 2)
  {
    std::cout << "\n\n  Expected path text patterns and file patterns on command line";
    std::cout << "\n  /p path /f filePat1 ... /t textPat1 ...";
    return false;
  }
  // ToDo: clean up the indexing logic - should be simpler

  size_t i = 0;
  while (++i < argc)
  {
    if (argv[i][0] == '/' && argv[i][1] == 'p')
    {
      path_ = argv[++i];
      continue;
    }
    if(argv[i][0] == '/' && argv[i][1] == 'f')
    {
      ++i;
      while (i < argc && argv[i][0] != '/') {
        filePatterns_.push_back(argv[i]);
        ++i;
      }
      --i;
      continue;
    }
    if (argv[i][0] == '/' && argv[i][1] == 't')
    {
      ++i;
      while (i < argc && argv[i][0] != '/') {
        textPatterns_.push_back(argv[i]);
        ++i;
      }
      --i;
      continue;
    }
  }
  return true;
}
//----< creates a ParallelTextSearch instance and starts it up >-----

void AnalysisExecutive::doAnalysis()
{
  Show::write("\n  Starting text search");

  std::string msg = "\n  numFilesProcessed will be displayed as zero until FileMgr";
  msg += "\n  notifies Display of the number of files processed\n";
  Show::write(msg);
  ParallelTextSearch exec(path_);
  for (auto pattern : filePatterns_)
    exec.addFilePattern(pattern);
  for (auto pattern : textPatterns_)
    exec.addTextPattern(pattern);
  exec.start();
  exec.wait();  // wait for display to complete
  Show::write("\n  Text search complete\n");

  exec.stop();  // shut down thread pool
  Show::stop();
  DebugLog::stop();
}

#ifdef TEST_ANALYSIS

int main(int argc, char* argv[])
{
  Utils::Title("Testing Parallel Text Search Facility");

  Show::attach(&std::cout);
  Show::start();
  DebugLog::attach(&std::cout);

  AnalysisExecutive exec;
  if(!exec.parseCommandLine(argc, argv))
    return 1;
  exec.doAnalysis();
}
#endif
