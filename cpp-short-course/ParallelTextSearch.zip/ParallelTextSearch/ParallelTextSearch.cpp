/////////////////////////////////////////////////////////////////////////
// ParallelTextSearch.cpp - This package searches for text in filies   //
//                                                                     //
// Jim Fawcett, CSE775 - Distributed Objects, Spring 2016              //
/////////////////////////////////////////////////////////////////////////

#include "ParallelTextSearch.h"
#include "../Utilities/Utilities.h"

//----< add text pattern to collection >-----------------------------

void TextSearch::addTextPattern(const TextPattern& pattern)
{
  textPatterns_.push_back(pattern);
}
//----< search for all text patterns in single file >----------------

void TextSearch::doTextSearch(const TextSearch::File& filename)
{
  // Sleep is here so Result display doesn't process all Results and
  // block on Result queue before notification by FileMgr of number
  // of files processed.

  ::Sleep(1);

  FileSystem::File f(filename);
  std::string fileText;
  if (f.open(FileSystem::File::direction::in))
  {
    while (f.isGood())
      fileText += f.getLine() + " ";
  }
  for (auto pattern : textPatterns_)
  {
    if (fileText.find(pattern) < fileText.size())
    {
      resultsQ_.enQ(filename);
      return;
    }
  }
  resultsQ_.enQ("text not found");
}
//----< initialize SearchDisplay and its done event >-------------------

SearchDisplay::SearchDisplay(BlockingQueue<TextSearch::Result>& resultsQ)
  : resultsQ_(resultsQ), dnEvt_(this)
{
  future_ = promise_.get_future();  // needed for wait function
}
//----< register done event handler with FileMgr >-------------------

void SearchDisplay::registerForDone(FileManager::IFileMgr* pFileMgr)
{
  pFileMgr->regForDone(&dnEvt_);
  numFilesProcessed_.store((size_t)0);
}
//----< display processing counts >-----------------------------------

void showCounts(std::atomic<size_t>& numFilesProcessed, size_t numResultsProcessed)
{
  Show::write(
    "\n  - numFilesProcessed = " +
    Utilities::Converter<size_t>::toString(numFilesProcessed.load())
    );
  Show::write(
    "\n  - numResultsProcessed = " +
    Utilities::Converter<size_t>::toString(numResultsProcessed)
    );
}
//----< pretend to merge symbol Results >-----------------------------

TextSearch::Result SearchDisplay::display()
{
  TextSearch::Result Result;
  numResultsProcessed_ = 0;
  while (true)
  {
    // The test, below, prevents merge from blocking on Result queue after all the Results
    // have been processed.  It assumes that each file analysis will generate a Result,
    // even if empty.

    if ((numFilesProcessed_.load() == 0) || (numResultsProcessed_ < numFilesProcessed_.load()))
    {
      ++numResultsProcessed_;
      showCounts(numFilesProcessed_, numResultsProcessed_);

      Result = resultsQ_.deQ();
      merged_ += Result;
      merged_ += " ";
      Show::write(
        "\n -- " +
        Result + " --"
      );
      if (Result == "quit")
      {
        Show::write("\n -- waiting in spin lock --");
        while (numFilesProcessed_.load() == 0)  // spin waiting for event to
          ::Sleep(10);                          // propagate to this instance
      }
      showCounts(numFilesProcessed_, numResultsProcessed_);
      /*
       * We could have used a condition variable or promise/future to wait
       * efficiently.  However this will always be a very short interval of
       * time since we are just waiting for the FileManger to tell us how
       * many files it processed after we receive a quit message from the
       * text search process.  So this simplicity is preferable.
       */
    }
    else
    {
      Show::write("\n  releasing future");
      promise_.set_value(numFilesProcessed_);  // unblocks future
      break;
    }
  }
  return merged_;
}
//----< called by SearchDoneEventHandler::execute(...) >------------

void SearchDisplay::done(size_t numFilesProcessed)
{
  Show::write("\n------- done event handled in SearchDisplay -------");
  numFilesProcessed_.store(numFilesProcessed);
}
//----< ParallelTextSearch calls to wait for merge to finish >------

size_t SearchDisplay::wait()
{
  size_t numFiles = future_.get();
  return numFiles;
}
//----< initlze Exec and TypeAnal, SearchDisplay, and evnt hndlrs >-----

ParallelTextSearch::ParallelTextSearch(const Path& path)
  : ta_(resultsQueue_), tm_(resultsQueue_), fevt_(this), devt_(this), dnEvt_(this)
{
  FileManager::FileMgrFactory factory;
  pFileMgr_ = factory.create(path);
  pFileMgr_->regForFiles(&fevt_);
  pFileMgr_->regForDirs(&devt_);
  pFileMgr_->regForDone(&dnEvt_);
  tm_.registerForDone(pFileMgr_);
}
//----< add to file patterns collection >----------------------------

void ParallelTextSearch::addFilePattern(const FilePattern& pattern)
{
  pFileMgr_->addPattern(pattern);
}
//----< add to text patterns collection >----------------------------

void ParallelTextSearch::addTextPattern(const TextPattern& pattern)
{
  ta_.addTextPattern(pattern);
}
//----< start up the processing pipeline >---------------------------

void ParallelTextSearch::start()
{
  tdco_ = [this]() -> bool
  {
    Show::write("\n  starting results display");
    tm_.display();
    return true;
  };
  task_.workItem(tdco_);

  fsco_ = [this]()
  {
    Show::write("\n  starting file search");
    pFileMgr_->search();
    return true;
  };
  task_.workItem(fsco_);
}
//----< shut down the threadpool >-----------------------------------

void ParallelTextSearch::stop()
{
  CallObj exit = []() -> bool { return false; };
  task_.workItem(exit);
}
//----< wait for the merge process to finish >-----------------------

void ParallelTextSearch::wait()
{
  tm_.wait();
}
//----< handler for file events from FileMgr >-----------------------

void ParallelTextSearch::file(const File& file)
{
  DebugLog::write("\n  analyzing file \"" + file + "\"");
  File fileSpec = path_ + "\\" + file;
  taco_ = [this, fileSpec]() -> bool {
    ta_.doTextSearch(fileSpec);
    return true;
  };

  task_.workItem(taco_);  // threadpool will make copy
}
//----< handler for dir events from FileMgr >------------------------

void ParallelTextSearch::dir(const Path& path)
{
  path_ = path;
}
//----< handler for done event from FileMgr, not used >--------------

void ParallelTextSearch::done(size_t numFilesProcessed)
{
  fileSearchDone = true;
  resultsQueue_.enQ("quit");
}

void AnalFileEventHandler::execute(const std::string& file)
{
  pExec_->file(file);
}

void AnalDirEventHandler::execute(const std::string& dir)
{
  pExec_->dir(dir);
}

void AnalDoneEventHandler::execute(size_t numFilesProcessed)
{
  pExec_->done(numFilesProcessed);
}

void SearchDoneEventHandler::execute(size_t numFilesProcessed)
{
  pTM_->done(numFilesProcessed);
}

#ifdef TEST_PARALLELTYPEANAL

using namespace Utilities;
using Utils = StringHelper;

int main()
{
  Utils::Title("Testing MockDepAnal");

  Show::attach(&std::cout);
  Show::start();
  DebugLog::attach(&std::cout);

  std::string msg = "\n  numFilesProcessed will be displayed as zero until FileMgr";
  msg += "\n  notifies SearchDisplay of the number of files processed\n";
  Show::write(msg);
  ParallelTextSearch exec("../..");
  exec.addPattern("*.h");
  exec.addPattern("*.cpp");
  exec.start();
  exec.wait();  // wait for Result merge to complete
  exec.stop();  // shut down thread pool - in full solution won't do this
                // until the end of Pass #2
  Show::stop();
  DebugLog::stop();
}
#endif
