#pragma once
/////////////////////////////////////////////////////////////////////////
// ParallelTextSearch.h - This package conducts simple text searches   //
//                                                                     //
// Jim Fawcett, CSE775 - Distributed Objects, Spring 2016              //
/////////////////////////////////////////////////////////////////////////
/*
 * This package conducts text searches in multiple files, using a ThreadPool
 * and Task class to manage a lot of concurrency in a relatively easy way.
 *
 * It depends on the packages:
 * - ParallelTextSearch - ParallelTextSearch, TextSearch, SearchDisplay, 
 *                        and EventHandler classes
 * - IFileMgr           - IFileMgr, IFileEventHandler, IDirEventHandler, and 
 *                        IDoneEvent Handler interfaces
 * - FileMgr            - FileMgr class
 * - Task               - Task class
 * - ThreadPool         - ThreadPool class
 * - Logger             - Logger and StaticLogger<size_t>
 * - BlockingQueue      - BlockingQueue<T> used by the three previous packages
 * - Utilities          - Converter<T> has toString and toValue methods, 
 *                        and several other helper classes
*/
#include <string>
#include <iostream>
#include <sstream>
#include <future>
#include <atomic>
#include "../Cpp11-BlockingQueue/Cpp11-BlockingQueue.h"
#include "../FileMgr/IFileMgr.h"
#include "../FileMgr/FileMgr.h"
#include "../Logger/Logger.h"
#include "../Utilities/Utilities.h"
#include "../Tasks/Task.h"

using Show = StaticLogger<0>;
using DebugLog = StaticLogger<1>;

/////////////////////////////////////////////////////////////////////
// TextSearch class
// - Responsible for finding text strings in a single file.
// - Reads file as a single string and looks for each text pattern.
//
class TextSearch
{
public:
  using File = std::string;
  using Result = std::string;  // simple for demo
  using TextPattern = std::string;
  using TextPatterns = std::vector<TextPattern>;

  TextSearch(BlockingQueue<Result>& resultsQ) 
    : resultsQ_(resultsQ) {}

  void addTextPattern(const TextPattern& pattern);
  void doTextSearch(const File& filename);

private:
  BlockingQueue<Result>& resultsQ_;
  TextPatterns textPatterns_;
};

/////////////////////////////////////////////////////////////////////
// SearchDisplay class
// - Responsible for displaying Results as they arrive in Result queue
// - For complete solution this becomes package SearchDisplay
//
class SearchDisplay;

class SearchDoneEventHandler : public FileManager::IDoneEventHandler
{
public:
  SearchDoneEventHandler(SearchDisplay* pTM) : pTM_(pTM) {}
  void execute(size_t numFilesProcessed);
private:
  SearchDisplay* pTM_;
};

class SearchDisplay
{
public:
  SearchDisplay(BlockingQueue<TextSearch::Result>& resultsQ);
  void registerForDone(FileManager::IFileMgr* pFileMgr);
  TextSearch::Result display();
  void done(size_t numFilesProcessed);
  size_t wait();
private:
  BlockingQueue<TextSearch::Result>& resultsQ_;
  TextSearch::Result merged_;
  size_t numResultsCreated = 0;
  FileManager::IFileMgr* pFileMgr_;
  SearchDoneEventHandler dnEvt_;
  std::atomic<size_t> numFilesProcessed_;  // shared by FileMgr and SearchDisplay
  size_t numResultsProcessed_ = 0;
  std::future<size_t> future_;
  std::promise<size_t> promise_;
};

/////////////////////////////////////////////////////////////////////
// Analysis Event Handlers

class ParallelTextSearch;

class AnalFileEventHandler : public FileManager::IFileEventHandler
{
public:
  AnalFileEventHandler(ParallelTextSearch* pExec) : pExec_(pExec) {}
  void execute(const std::string& file);
private:
  ParallelTextSearch* pExec_;
};

class AnalDirEventHandler : public FileManager::IDirEventHandler
{
public:
  AnalDirEventHandler(ParallelTextSearch* pExec) : pExec_(pExec) {}
  void execute(const std::string& dir);
private:
  ParallelTextSearch* pExec_;
};

class AnalDoneEventHandler : public FileManager::IDoneEventHandler
{
public:
  AnalDoneEventHandler(ParallelTextSearch* pExec) : pExec_(pExec) {}
  void execute(size_t numFilesProcessed);
private:
  ParallelTextSearch* pExec_;
};

/////////////////////////////////////////////////////////////////////
// ParallelTextSearch class
// - Responsible for creating FileManager, TextSearch, and SearchDisplay
// - Runs FileMgr::search(), TextSearch::doTextSearch(), and SearchDisplay::display()
//   on ThreadPool threads, using the Task class
//
class ParallelTextSearch
{
public:
  using File = std::string;
  using Path = std::string;
  using FilePattern = std::string;
  using TextPattern = std::string;
  using CallObj = std::function<bool()>;

  ParallelTextSearch(const Path& path);
  void addFilePattern(const FilePattern& pattern);
  void addTextPattern(const TextPattern& pattern);
  void start();
  void stop();
  void wait();
  void file(const File& file);
  void dir(const Path& path);
  void done(size_t numFilesProcessed);
private:
  TextSearch ta_;
  SearchDisplay tm_;
  BlockingQueue<TextSearch::Result> resultsQueue_;
  Path path_;
  Task<8> task_;
  FileManager::IFileMgr* pFileMgr_;
  AnalFileEventHandler fevt_;
  AnalDirEventHandler devt_;
  AnalDoneEventHandler dnEvt_;
  bool fileSearchDone = false;
  CallObj tdco_;  // results display
  CallObj taco_;  // text analysis
  CallObj fsco_;  // file search
};
