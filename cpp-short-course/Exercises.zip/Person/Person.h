#pragma once
// Person.h - First Exercise

#include <string>

/*
 * Note:
 * - We don't need to provide copy constructors, assignment operators
 *   and destructor, as the members of Person have correct semantics
 *   for those operations, so compiler generated operations will be
 *   correct.
 */
class Person
{
public:
  using Name = std::string;
  using Job = std::string;
  using City = std::string;

  Person(const Name& name, const Job& job, const City& city);
  Name name() const;
  Job job() const;
  City city() const;
private:
  Name name_;
  Job  job_;
  City city_;
};