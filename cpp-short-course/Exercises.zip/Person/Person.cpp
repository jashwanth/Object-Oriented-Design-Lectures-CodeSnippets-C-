// Person.cpp

#include "Person.h"
#include <iostream>

Person::Person(const Name& name, const Job& job, const City& city) : name_(name), job_(job), city_(city) {}
Person::Name Person::name() const { return name_; }
Person::Job Person::job() const { return job_; }
Person::City Person::city() const { return city_; }

void show(const Person& person)
{
  std::cout << "\n  " << person.name() << " is a " << person.job() << " living in " << person.city();
}

int main()
{
  Person Bob("Bob", "SWDev", "Syracuse");
  show(Bob);
  Person Shirley("Shirley", "Child Star", "Hollywood");
  show(Shirley);
  Person Jack("The Ripper", "Stalker", "London");
  show(Jack);
  std::cout << "\n\n";
}