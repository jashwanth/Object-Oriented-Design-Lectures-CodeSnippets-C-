#pragma once
/////////////////////////////////////////////////////////////////
// Person.h - Exercise #2                                      //
//                                                             //
// Jim Fawcett, Short Course, Summer 2016                      //
/////////////////////////////////////////////////////////////////

#include <string>
#include <unordered_map>

/*
 * Note:
 * - We don't need to provide copy constructors and assignment operators
 *   as the members of Person have correct semantics for those operations,
 *   so compiler generated operations will be correct.  We do need to 
 *   provide a virtual destructor so deleting of derived instances works
 *   as expected.
 * - Same for the derived classes as they don't have any data members
 *   and their base is People with correct semantics.
 */
class Person
{
public:
  using PeopleProps = std::unordered_map<std::string, std::string>;
  using Name = std::string;
  using Job = std::string;
  using City = std::string;
  using prName = std::string;
  using prValue = std::string;

  Person(const Name& name, const Job& job, const City& city);
  Name name();
  Job job();
  City city();
  void show();

  void addProperty(const prName& name, const prValue& value);
  PeopleProps properties();

  virtual void doWork();
  virtual void doPlay();
  virtual ~Person() {}
private:
  PeopleProps properties_;
};

class SWDev : public Person
{
public:
  SWDev(const Name& name, const Job& job, const City& city);
  virtual void doWork();
  virtual void doPlay();
};

class MLBallPlayer : public Person
{
public:
  MLBallPlayer(const Name& name, const Job& job, const City& city);
  virtual void doWork();
  virtual void doPlay();
};

class FinancialAdvisor : public Person
{
public:
  FinancialAdvisor(const Name& name, const Job& job, const City& city);
  virtual void doWork();
  virtual void doPlay();
};
