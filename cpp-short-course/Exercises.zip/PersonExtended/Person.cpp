/////////////////////////////////////////////////////////////////
// Person.cpp - Exercise #2                                    //
//                                                             //
// Jim Fawcett, Short Course, Summer 2016                      //
/////////////////////////////////////////////////////////////////

#include "Person.h"
#include <iostream>

Person::Person(const Name& name, const Job& job, const City& city) 
{
  properties_["Name"] = name;
  properties_["Job"] = job;
  properties_["City"] = city;
}

Person::Name Person::name() { return properties_["Name"]; }
Person::Job Person::job() { return properties_["Job"]; }
Person::City Person::city() { return properties_["City"]; }

void Person::addProperty(const prName& name, const prValue& value)
{
  properties_[name] = value;
}

Person::PeopleProps Person::properties() { return properties_; }

void Person::doWork()
{
  std::cout << "\n  I don't do work yet";
}

void Person::doPlay()
{
  std::cout << "\n  no fun";
}

void Person::show()
{
  std::cout << "\n  " << name() << " is a " << job() << " living in " << city();
  for (auto item : properties_)
  {
    if (item.second == name())
      continue;
    if (item.second == job())
      continue;
    if (item.second == city())
      continue;
    std::cout << ", " << item.first << " = " << item.second;
  }
}

SWDev::SWDev(const Name& name, const Job& job, const City& city) : Person(name, job, city) {}
void SWDev::doWork()
{
  std::cout << "\n  designing, coding, debugging, debugging, ...";
}
void SWDev::doPlay()
{
  std::cout << "\n  eating pizza with buddies";
}

MLBallPlayer::MLBallPlayer(const Name& name, const Job& job, const City& city) : Person(name, job, city) {}
void MLBallPlayer::doWork()
{
  std::cout << "\n  catching flies, hitting homers";
}
void MLBallPlayer::doPlay()
{
  std::cout << "\n  wining and dining gorgeous babes";
}
FinancialAdvisor::FinancialAdvisor(const Name& name, const Job& job, const City& city) : Person(name, job, city) {}
void FinancialAdvisor::doWork()
{
  std::cout << "\n  setting up accounts, buying, selling";
}
void FinancialAdvisor::doPlay()
{
  std::cout << "\n  yatching on the mediteranean";
}

int main()
{
  Person Bob("Bob", "SWDev", "Syracuse");
  Bob.show();
  std::cout << "\n";

  Person Shirley("Shirley", "Child Star", "Hollywood");
  Shirley.addProperty("Hair", "Curly locks");
  Shirley.show();
  std::cout << "\n";

  Person Jack("The Ripper", "Stalker", "London");
  Jack.addProperty("Identity", "Unknown");
  Jack.show();
  std::cout << "\n";

  SWDev Adam("Adam", "SWDev", "Utica");
  Adam.show();
  Adam.doWork();
  Adam.doPlay();
  std::cout << "\n";

  MLBallPlayer Carl("Carl", "Left Fielder", "Boston");
  Carl.show();
  Carl.doWork();
  Carl.doPlay();
  std::cout << "\n";

  FinancialAdvisor Wolf("Wolf", "Financial Advisor", "New York City");
  Wolf.show();
  Wolf.doWork();
  Wolf.doPlay();
  std::cout << "\n";

  std::cout << "\n\n";
}