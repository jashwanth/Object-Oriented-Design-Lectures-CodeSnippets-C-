/* 
 * File:   Host.cpp - Demonstrates dynamic plugin processing
 * Author: Jim Fawcett, ShortCourse, Summer 2016
 *
 * Created on May 30, 2016, 9:32 AM
 */

#include <cstdlib>
#include <dlfcn.h>
#include <iostream>
#include <string>
#include "IPlugin.h"

void title(const std::string& text)
{
  std::cout << "\n  " << text.c_str();
  std::cout << "\n " << std::string(text.size() + 2, '=');
}
int main(int argc, char** argv) {
  
  title("Demonstrate Dynamic Plugin");
  
  /* load shared library */
  void* lib_handle = dlopen("../DynamicPluginLibrary/dist/Debug/CLang-Linux/libDynamicPluginLibrary.so", RTLD_LAZY);
  if(!lib_handle)
  {
    std::cout << "\n  could'nt load libDynamicPluginLibrary.so";
    exit(1);
  }
  std::cout << "\n  load library succeeded";
  
  /* get reference to activePlugin function*/
  IPlugin*(*openPlugin)();
  void* ptr = dlsym(lib_handle, "activatePlugin");
  openPlugin = (IPlugin*(*)())ptr;
  if(dlerror())
  {
    std::cout << "\n  " << dlerror();
    exit(1);
  }
  std::cout << "\n  create reference to activation function succeeded";
  
  /* now use plugin */
  std::cout << "\n  activating plugin";
  IPlugin* pPlugin = openPlugin();
  
  pPlugin -> doWork();
  
  std::cout << "\n  closing plugin";
  pPlugin -> close();
  std::cout << "\n\n";
  return 0;
}

