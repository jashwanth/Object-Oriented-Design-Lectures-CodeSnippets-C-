/* 
 * File:   Plugin.cpp - defines plugin processing
 * Author: Jim Fawcett, ShortCourse, Summer 2016
 *
 * Created on May 30, 2016, 9:32 AM
 */

#include "../PluginHost/IPlugin.h"
#include <iostream>

class Plugin : public IPlugin
{
  public:
    virtual void doWork()
    {
      std::cout << "\n  Plugin working!";
    }
    virtual void close()
    {
      delete this;
    }
};

extern "C" IPlugin* IPlugin::openPlugin()
{
  return new Plugin;
}