/* 
 * File:   Host.cpp - Demonstrates basic plugin processing
 * Author: Jim Fawcett, ShortCourse, Summer 2016
 *
 * Created on May 30, 2016, 9:32 AM
 */

#include <cstdlib>
#include <iostream>
#include <string>
#include "IPlugin.h"

void title(const std::string& text)
{
  std::cout << "\n  " << text.c_str();
  std::cout << "\n " << std::string(text.size() + 2, '=');
}
int main(int argc, char** argv) {
  
  title("Demonstrate Basic Plugin");
  
  std::cout << "\n  activating plugin";
  IPlugin* pPlugin = IPlugin::openPlugin();
  
  pPlugin -> doWork();
  
  std::cout << "\n  closing plugin";
  pPlugin -> close();
  std::cout << "\n\n";
  return 0;
}

