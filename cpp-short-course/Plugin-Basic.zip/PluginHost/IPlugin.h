/* 
 * File:   IPlugin.h - plugin interface
 * Author: Jim Fawcett, ShortCourse, Summer 2016
 *
 * Created on May 30, 2016, 9:32 AM
 */


#ifndef IPLUGIN_H
#define IPLUGIN_H

extern "C" {
  struct IPlugin {
    static IPlugin* openPlugin();
    virtual void close() = 0;
    virtual void doWork() = 0;
    virtual ~IPlugin() {};
  };
}
#endif /* IPLUGIN_H */

