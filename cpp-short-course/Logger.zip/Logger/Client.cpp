///////////////////////////////////////////////////////////////////////////////
// Client.cpp - Client of Logger class                                       //
//                                                                           //
// Jim Fawcett, Solution second week Wednesday exercise                      //
// Short Course, Summer 2016                                                 //
///////////////////////////////////////////////////////////////////////////////

#include "Logger.h"
#include <iostream>
#include <fstream>
#include <thread>

int main()
{
  // create and use standard out logger

  Logger<StdOutWriter> logger("Jim Fawcett");
  logger.logTitle("Console Log Messages");
  logger.log("first success message");
  logger.log("second success message");
  logger.log("no failures here!");

  // wait long enough that message time stamps are different 

  std::this_thread::sleep_for(std::chrono::milliseconds(1000));
  
  // create and use File Logger

  Logger<FileWriter> flogger("Alfred E. Neuman");
  flogger.writer().open("logFile.txt");
  flogger.logTitle("File Log Messages");
  flogger.log("What - me worry?");
  flogger.log("Still not worried!");
  flogger.log("Whatever happened to Mad Magazine?");
  flogger.writer().close();

  // display the logged messages

  std::ifstream in("logFile.txt");
  std::cout << in.rdbuf();
  in.close();

  std::cout << "\n\n";
}